/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodenetwork;
import java.util.*;
/**
 *
 * @author w1669293
 */
public class Graph {

    private String name;
    private int[] flow;
    private ArrayList<Edge> X;
    private ArrayList<Node> Y;
    private int[] flowLedger;

    public Graph(String name, int[] flow, ArrayList<Edge> X, ArrayList<Node> Y, int[] flowLedger) {
        this.name = name;
        this.flow = flow;
        this.X = X;
        this.Y = Y;
        this.flowLedger = flowLedger;
    }

    public String getName() {
        return name;
    }

    public int[] getFlow() {
        return flow;
    }

    public void setFlow(int[] flow) {
        this.flow = flow;
    }

    public ArrayList<Edge> getX() {
        return X;
    }

    public void setX(ArrayList<Edge> X) {
        this.X = X;
    }

    public ArrayList<Node> getY() {
        return Y;
    }

    public void setY(ArrayList<Node> Y) {
        this.Y = Y;
    }

    public int[] getFlowLedger() {
        return flowLedger;
    }

    public void setFlowLedger(int[] flowLedger) {
        this.flowLedger = flowLedger;
    }

    
}


