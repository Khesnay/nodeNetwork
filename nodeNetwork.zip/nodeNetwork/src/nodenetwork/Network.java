/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodenetwork;

import java.util.*;

/**
 *
 * @author w1669293
 */
public class Network extends Node {

    /*
    This class will be acting as a Graph manager where methods will be implemented.
     */
    private ArrayList<Edge> networkLink;
    private ArrayList<Node> nodeNetwork;
    Random r = new Random();
    private int nameList, nodeNum, fCap;
    private Node[] nodeNet;
    private ArrayList<Integer> Flow = new ArrayList<>(Arrays.asList(5, 3, 8, 10,1,2)); // Flow to be distributed!
    private ArrayList<Edge> deletedEdge = new ArrayList<>();
    private ArrayList<Node> deletedNode = new ArrayList<>();

    public void Menu() {
        Scanner in = new Scanner(System.in);
        String userInput;
        ArrayList toName = new ArrayList<>(Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J")); // NAME FOR NODES
        int g, h, i, j, k; // Used for Loops
        boolean exit = true;
        System.out.println("Welcome to Max Flow Calculator Generation V.2. Press X to exit.");
        
        

        
        
        
        // Push Flow through network

        while (exit) {
            userInput = in.nextLine().toUpperCase();
            switch (userInput) {
                case "A":
                    generate(); // Generate node and Edges
                    getNodeArray(); // Display Nodes
                    getEdgeArray(); // Display Edges

                    break;
                case "B":
                    toLink(); // Link Edges and Nodes
                    NetworkDisplay();
                    break;

                case "C":
                    for (int u = 0; u < this.Flow.size(); u++) {
                        homyGod(this.Flow.get(u));
                    }
                    break;
                case "D":
                    getNodeArray(); // Display Nodes
                    getEdgeArray(); // Display Edges
                    break;

                case "E":
                    NetworkDisplay(); // Display current Network
                    break;

                case "F":
                    addEdge();
                    break;



                case "X":
                    System.out.println("Okay good bye!");
                    exit=false;
                    break;
                default:
                    System.out.println("Have you pressed the right key?");
                    break;
                    
            }
        }
//            
//            
//            
//            
//        }
    }

    public void generate() {
        ArrayList toName = new ArrayList<>(Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J"));
        ArrayList toEdge = new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10"));
        nodeNum = r.nextInt(5) + 6; // Give a number between 4 and 10 to assign a number of nodes
        this.nodeNet = new Node[nodeNum];
        Node S, T, V;
        Edge W;

        S = new Node();
        S.setName("Source");
        T = new Node();
        T.setName("Sink");
        this.nodeNet[0] = S; // First position is SOURCE
        this.nodeNet[nodeNum - 1] = T; // Last position is SINK
        this.nodeNetwork = new ArrayList<>();
        this.nodeNetwork.add(S);
        this.networkLink = new ArrayList<>();
        //this.nodeNetwork.set(nodeNum, T);
        //this.nodeNetwork.set(0, S);
        int count = 0;

        for (int a = 0; a < nodeNum; a++) {
            nameList = r.nextInt(toName.size()) + 0; // Randomize the choosen name each time its loop
            fCap = r.nextInt(15) + 5;

//__________________________ SET UP NODES_______________________________________  
            if (a > 0 && a < (nodeNum - 1)) {
                V = new Node();
                V.setName((String) toName.get(nameList)); // Choose a random name for Node
                //V.setFlowLedger(0);
                toName.remove(nameList);
                V.getFlowLedger().add(0);
                this.nodeNet[a] = V; // used as referencial in case
                this.nodeNetwork.add(V);

            }
//___________________________SET UP EDGES_______________________________________
            String K = String.valueOf(count);// Change counter as a String to name Edges
            W = new Edge();
            W.setMaxFlowCap(fCap); // Set up Flow Cap for Edges
            W.setName(K);
            this.networkLink.add(W);
            count++;
            //USE TO DEBUG. Check nodeNet

//            System.out.println(nodeNet[0].getName());
//            System.out.println("Array length: "+this.nodeNet.length);
//            System.out.println(this.nodeNet.length-1+" :"+this.nodeNet[this.nodeNet.length-1].getName());
//            System.out.println(a+":"+this.nodeNet[a].getName()+"\n"); 
        }
        this.nodeNetwork.add(T); // Add sink lastly

    }

    // Print Node Arrays
    public void getNodeArray() {
        System.out.print("NODES : [");
        for (int a = 0; a < nodeNet.length; a++) {
            System.out.print(this.nodeNetwork.get(a).getName() + " ");
        }
        System.out.print("] number of nodes " + nodeNet.length + " <!> NB: (Source and Sink are included)\n");
    }

    // Print Edge Arrayx
    public void getEdgeArray() {
        System.out.print("EDGES: [");
        for (int i = 0; i < this.networkLink.size(); i++) {
            System.out.print(this.networkLink.get(i).getName() + " ");

        }
        System.out.println("] number of Edges: " + this.networkLink.size() + "");
    }

    public void toLink() {
        Node Source = this.nodeNetwork.get(0);
        Node Sink = this.nodeNetwork.get(this.nodeNetwork.size() - 1);
        for (int H = 0; H < this.networkLink.size(); H++) {
            // USED TO ASSIGN NODE TWO BY TWO
            int G, K, J, I;
            G = H + 1;
            K = H + 2;
            I = H - 1;
            J = H - 2;
            Node actualNode = this.nodeNetwork.get(H);
            Edge currentEdge = this.networkLink.get(H);
//            if (this.networkLink.size() % 2 == 0) { // Check if whole Array is Even, otherwise proceed differently
            if (H < 2) {// ALLOCATE THE FIRST TWO NODES TO SOURCE
                currentEdge.setLink(Source, this.nodeNetwork.get(G));
            } else if (H > this.networkLink.size() - 3) { // ALLOCATE THE LAST TWO NODES TO SINK

                currentEdge.setLink(this.nodeNetwork.get(I), Sink);

            } else { // ALLOCATE IT TO THE REST
                if (H % 2 == 0) {

                    currentEdge.setLink(this.nodeNetwork.get(I), this.nodeNetwork.get(G));

                } else if (H % 2 == 1) {

                    currentEdge.setLink(this.nodeNetwork.get(I), this.nodeNetwork.get(G));
                }

            }

        }

    }

    public void homyGod(int j) {
        Node Source = this.nodeNetwork.get(0);
        Node Sink = this.nodeNetwork.get(this.nodeNetwork.size() - 1);
        //this.Flow.remove(1);

        Source.getFlowLedger().add(j);
        ArrayList<Edge> pushIt = new ArrayList<>();
        for (int A = 0; A < this.networkLink.size(); A++) {// GO THROUGH ARRAYLIST OF EDGES
                    
            int B, C, D, E;
            B = A + 1;
            C = A + 2;
            D = A - 2;
            E = A - 1;

            Edge currentEdge = this.networkLink.get(A);
            int nodeS = currentEdge.link.get(0).getFlowLedger().get(currentEdge.link.get(0).getFlowLedger().size() - 1);

            int edgeValue = currentEdge.getFlowLedger().get(currentEdge.getFlowLedger().size()-1);
            //System.out.println(nodeS);

            Node currentLinkZero = currentEdge.link.get(0);
            int available = currentEdge.getMaxFlowCap() - this.networkLink.get(A).getCurrentCap(); // FLOW CAP - CURRENT VALUES as integer 

            Edge preOne, preTwo, nextOne, nextTwo;
            //System.out.println(currentEdge.link.get(0).getFlowLedger());
            //System.out.println(currentEdge.actualCap());
            //System.out.println(edgeValue);

            if (nodeS <= currentEdge.actualCap()) {
                if (A < 2) {
                    nextOne = this.networkLink.get(B);
                    nextTwo = this.networkLink.get(C);
                    if (currentEdge.link.get(1).hashCode() == nextTwo.link.get(0).hashCode()&&currentEdge.isDirection()==true) {
                        // System.out.println(currentEdge.getName()+" CONNECTED TO EDGE: "+ nextTwo.getName() );

                        if (currentEdge.actualCap() > nextOne.actualCap()) { // Always pick up the biggest actual Flow Cap 

                            // CHECK IF CURRENT VALUE CAN BE PUSHED THROUGH
                            if (j > nextTwo.actualCap()) { // if next Edge cannot take it, switch everything to zero
                                nextOne.addToFlowLedger(0);
                                nextOne.link.get(1).addToFlowLedger(0);
                                currentEdge.addToFlowLedger(0);
                                currentEdge.link.get(1).addToFlowLedger(0);
                                
                                pushIt.add(currentEdge); // Security
          

                            } else {
                                
                                currentEdge.addToFlowLedger(j);
                                currentEdge.link.get(1).addToFlowLedger(j);
                                nextOne.addToFlowLedger(0);
                                nextOne.link.get(1).addToFlowLedger(0);
                                pushIt.add(currentEdge); // Security
                          
                            }
                            A++;

                            //System.out.println(Source.getName() + " CONNECTED TO  EDGE " + currentEdge.getName());
                            //System.out.println("EDGE " + currentEdge.getName() + " VALUES " + currentEdge.getFlowLedger());
                            //System.out.println("EDGE "+currentEdge.getName()+" CURRENT VALUES :"+currentEdge.getFlowLedger()+" ACTUAL CAP: "+currentEdge.actualCap());
                        } else {
                            //
                            if (j > nextTwo.actualCap()) {
                                
                                nextOne.addToFlowLedger(0);
                                nextOne.link.get(1).addToFlowLedger(0);
                                currentEdge.addToFlowLedger(0);
                                currentEdge.link.get(1).addToFlowLedger(0);
                                pushIt.add(currentEdge); // Security
                               

                            } else {
                                currentEdge.addToFlowLedger(0);
                                currentEdge.link.get(1).addToFlowLedger(0);
                                nextOne.addToFlowLedger(j);
                                nextOne.link.get(1).addToFlowLedger(j);

                                //System.out.println("EDGE "+currentEdge.getName()+" CURRENT VALUES :"+currentEdge.getFlowLedger()+" ACTUAL CAP: "+currentEdge.actualCap());
                                pushIt.add(currentEdge);
                            }
                            A++;
                        }
                    }
//__________________________________________________________________________________SET UP SINK_________________________________________________________________________________________________________________________________________


                } else if (A >= networkLink.size() - 2) { // Add value to Sink whatever the value

                    currentEdge.addToFlowLedger(nodeS);
                    currentEdge.link.get(1).addToFlowLedger(nodeS);
                    //System.out.println("EDGE "+currentEdge.getName()+" CURRENT VALUES :"+currentEdge.getFlowLedger()+" ACTUAL CAP: "+currentEdge.actualCap());
                    //System.out.println(currentEdge.getName() + " CONNECTED TO  " + Sink.getName());
                    
//__________________________________________________________________________________SET UP EDGES AND NODES_________________________________________________________________________________________________________________________________________                   
                
                } else {
                    preOne = this.networkLink.get(E);
                    preTwo = this.networkLink.get(D);
                    nextTwo = this.networkLink.get(C);
                    //Edge laterEdge = this.networkLink.get(A+4);
                    if (currentEdge.isDirection() == true) {
                        if (currentEdge.link.get(0).hashCode() == preTwo.link.get(1).hashCode()) { // if connected then try to push in.
                          
                            if (nodeS > nextTwo.actualCap()) {
                                preTwo.addToFlowLedger(0);
                                preTwo.link.get(1).addToFlowLedger(0);
                                currentEdge.addToFlowLedger(0);
                                currentEdge.link.get(1).addToFlowLedger(0);

                                
                            } else {
                                currentEdge.addToFlowLedger(nodeS);
                                currentEdge.link.get(1).addToFlowLedger(nodeS);

                                pushIt.add(currentEdge);
                            }
                            //System.out.println(currentEdge.getFlowLedger());
                            //System.out.println(preTwo.getName() + " CONNECTED TO EDGE: " + currentEdge.getName() + " VIA " + currentEdge.link.get(0) + currentEdge.link.get(0).getFlowLedger());
                            //System.out.println(preTwo.getName() + " CONNECTED TO EDGE: " + currentEdge.getName() + " VIA " + currentEdge.link.get(0) + currentEdge.link.get(0).getFlowLedger());
                            //System.out.println("EDGE "+currentEdge.getName()+" CURRENT VALUES :"+currentEdge.getFlowLedger()+" ACTUAL CAP: "+currentEdge.actualCap());
                        }
                    }

                }

            } else {
               // preTwo = this.networkLink.get(D);
                //preOne = this.networkLink.get(E);
                currentEdge.addToFlowLedger(0);
                currentEdge.link.get(1).addToFlowLedger(0);
               // preOne.addToFlowLedger(0);
                //preOne.link.get(1).addToFlowLedger(0);
                
            }

        }
        
        //getNodeLedger();
   
      
        System.out.println(Sink.getFlowLedger());
        int maxFlow=0;
        for(int y=0;y<Sink.getFlowLedger().size();y++){
            maxFlow = maxFlow+Sink.getFlowLedger().get(y);
        }
        System.out.println("Maximum Flow is: "+maxFlow);

    }

    
    


    public void getNodeLedger(){
        System.out.println("\n");
        for(int U=0;U<this.networkLink.size();U++){
            System.out.println("EDGE: "+this.networkLink.get(U).getName()
                    +" LINKS: "+this.networkLink.get(U).link
                    +" EDGE VALUES LEDGER: "+this.networkLink.get(U).getFlowLedger() 
                    + " FLOW CAP: "+this.networkLink.get(U).getCurrentCap()
                    +"/"+this.networkLink.get(U).getMaxFlowCap()
                    +" REMAINING SPACE: "+this.networkLink.get(U).actualCap()
                    //+" LENGTH: "+this.networkLink.get(U).getFlowLedger().get(this.networkLink.get(U).getFlowLedger().size()-1)
            );
        }
    }
    
    public void NetworkDisplay(){
        for (int l = 0; l < this.networkLink.size(); l++) {
            System.out.println("EDGE: " + this.networkLink.get(l).getName() + " ==> LINK  " + this.networkLink.get(l).link+" FLOW CAP:"+this.networkLink.get(l).getCurrentCap()+"/"+networkLink.get(l).getMaxFlowCap());
        }
        System.out.println("\n");
    }
    
    public void addEdge(){
        Scanner in = new Scanner(System.in);
        Edge V = new Edge();
        System.out.println("Please enter a name.");
        String userName = in.nextLine();
        
        for(int i=0;i<this.networkLink.size();i++){
            if(userName.equals(this.networkLink.get(i).getName())){
                System.out.println("Sorry! Name is taken.");
            }else{
                V.setName(userName);
                
            }
        }System.out.println("Your entered: "+V.getName());
        
        System.out.println("Please enter a Flow Cap.");
        int userInt=in.nextInt();
        V.setMaxFlowCap(userInt);
        System.out.println("You entered: "+userInt);
        
        System.out.println("Please enter a direction value: 1 will allow Edge to transfer data, otherwise it can't");
        userInt = in.nextInt();
        userName = in.nextLine();
        V.setDirection(userInt);
        System.out.println("You entered: "+userInt+" Edge "+V.getName()+" is "+V.isDirection());
        
        System.out.println("Please enter two Nodes of the following list. BESIDE SINK AND SOURCE");
        System.out.println(this.nodeNetwork.subList(1, this.nodeNetwork.size()-1));

        for (int x = 1; x < this.nodeNetwork.size()-1; x++) {
            int rand = r.nextInt(this.nodeNetwork.size()-1)+1;
            int rand2 = r.nextInt(this.nodeNetwork.size()-1)+1;
            V.setLink(this.nodeNetwork.get(rand2), this.nodeNetwork.get(rand));
            System.out.println(this.nodeNetwork.get(rand2).getName()+"\n"+this.nodeNetwork.get(rand));
        } 
        Collections.swap(this.networkLink, this.networkLink.size()-1, this.networkLink.size()-2);
        Collections.swap(this.networkLink, this.networkLink.size()-2, this.networkLink.size()-3);
        this.networkLink.add(V);
        System.out.println(V);
        
        
        
        
    }
    public void deleteEdge(){
        Scanner in = new Scanner(System.in);
        getEdgeArray();
        System.out.println("Please enter a number from: "+this.networkLink.get(0).getName()+" to "+ this.networkLink.get(networkLink.size()-1));
        String userInp = in.nextLine();
        for(int i=0;i<this.networkLink.size();i++){
            if(userInp.equals(this.networkLink.get(i).getName())){
                this.deletedEdge.add(this.networkLink.get(i));
                this.networkLink.remove(this.networkLink.get(i));
            }else{
                System.out.println("Sorry, your entry doesn't seem to exist.");
            }
        }
        getEdgeArray();
        
    }
    
    public void deleteNode(){
        Scanner in = new Scanner(System.in);
        getNodeArray();
        System.out.println("Please enter a Node name <!> Sink and Source should not be deleted!");
        String userInp = in.nextLine();
        for(int i=0;i<this.nodeNetwork.size();i++){
            if(userInp.equals(nodeNetwork.get(i).getName())){
                this.deletedNode.add(this.nodeNetwork.get(i));
                this.nodeNetwork.remove(this.nodeNetwork.get(i));
               
            }else{
                System.out.println("Sorry, your entry doesn't seem to exist.");
            }
        } 
        getNodeArray();
    }   
}


    

        
    
    
    
    

