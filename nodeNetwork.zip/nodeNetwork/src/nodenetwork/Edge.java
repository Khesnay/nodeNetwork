/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodenetwork;
import java.util.*;
/**
 *
 * @author w1669293
 */
public class Edge extends Node {

    private int MaxFlowCap; // Randomly set from 5 to 20;
    private ArrayList<Integer> flowLedger; // Every flow going through will be recorded, sum of all integers cannot exceed MaxFlowCap
    private String name; // 
    private boolean direction;
    ArrayList<Node> link;
    
    
    public Edge(){
        this.MaxFlowCap = MaxFlowCap;
        this.name = name;
        this.direction = true;
        this.flowLedger = new ArrayList<>(Arrays.asList(0));
        
    }
    
    public Edge(int MaxFlowCap, ArrayList flowLedger,String name, boolean direction, ArrayList link){
        this.MaxFlowCap = MaxFlowCap;
        this.flowLedger = flowLedger;
        this.name = name;
        this.direction = direction;
        this.link=link;
    }
    
    public void setMaxFlowCap(int A){
        this.MaxFlowCap = A;
    }
    
    public int getMaxFlowCap(){
        
        return this.MaxFlowCap;
    }
    
    public int getCurrentCap(){
        int currentCap=0;
        for(int i=0;i<this.flowLedger.size();i++){
            currentCap = currentCap+this.flowLedger.get(i);
        }
        
        return currentCap;
    }
    
    public int actualCap(){
        int A = getMaxFlowCap()-getCurrentCap();
        return A;
    }


    public ArrayList<Integer> getFlowLedger() {
        return flowLedger;
    }
    
    public int FlowLength(){
        return flowLedger.size();
    }

    public void addToFlowLedger(int A) {
        this.flowLedger.add(A);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isDirection() {
        return direction;
    }

    public void setDirection(int B) {
        if(B==1){
            this.direction = true;
        }else{
            this.direction=false;
        }
        
    }

    public int getLink() {
        return this.link.size();
    }
    
    public void printLink() {
        int u;
        for (u = 0; u < this.link.size(); u++) {
            System.out.println(this.link);
        }
    }

    public void setLink(Node A,Node B) {
        
        this.link = new ArrayList<>();
        this.link.add(A); 
        this.link.add(B);
    }

    @Override
    public String toString() {
        return " Edge: " + name+" Maximum Flow Capacity: " + MaxFlowCap + " LINK:["+this.link.toString()+"]\n"; //+ " direction: " + direction + " link: " + link+"\n";
    }
    
    
    
}
